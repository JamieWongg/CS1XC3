var searchData=
[
  ['student_14',['Student',['../student_8h.html#ac91ec92866bb82e1ee36c75280929c43',1,'student.h']]],
  ['student_2ec_15',['student.c',['../student_8c.html',1,'']]],
  ['student_2eh_16',['student.h',['../student_8h.html',1,'']]]
];
