/**
 * @file course.c
 * @author Jamie Wong (you@domain.com)
 * @brief Library for Course related functions.
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */



#include "course.h"
#include <stdlib.h>
#include <stdio.h>
 
/**
 * @brief enroll_student function:
 * Adds a student to a course 
 * 
 * @param course 
 * @param student 
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++; //Increase total_students by 1
  //Only 1 student
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student)); //allocates space in the heap for one student (dynamic array decloration)
  }
  //More than 1 student
  else 
  {
    course->students = //re allocates dynamic array students to number of total_students
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student; //stores student into students array
}

/**
 * @brief print_course function:
 * Prints a Course's members
 * 
 * @param course 
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]); //iterates through the dynamic array students and prints each element
}

/**
 * @brief top_student function:
 * Finds the top student in a course by highest average and returns that student.
 * 
 * @param course 
 * @return Student* 
 */
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL; //If course has no students return NULL
 
  //Variable definitions
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
  
  //Iterates through students array
  for (int i = 1; i < course->total_students; i++) 
  {
    student_average = average(&course->students[i]);

    //If student_average is better than current max_average replace max_average and student.
    if (student_average > max_average) 
    {
      max_average = student_average; 
      student = &course->students[i]; 
    }   
  }

  return student;
}

/**
 * @brief passing function:
 * Finds and returns a dynamic array containing all students passing a given course. Array size returned in *total_passing.
 * 
 * @param course 
 * @param total_passing 
 * @return Student* 
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  //Iterates through array
  for (int i = 0; i < course->total_students; i++) 
    //counts number of passing students using count
    if (average(&course->students[i]) >= 50) count++; 

  passing = calloc(count, sizeof(Student)); //Array decloration in the heap
  int j = 0;

  //Iterates through array
  for (int i = 0; i < course->total_students; i++) 
  {
    //Adds passing students into dynamic array passing
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}