/**
 * @file student.h
 * @author Jamie Wong (you@domain.com)
 * @brief Contains structs, and function definitions for student.c 
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */

/**
 * @brief struct Student:
 * first_name, a string containing the first name.  
 * last_name, a string containing the last name.  
 * id, a string containing the student id.  
 * *grades, a dynamic array containing student grades (double).  
 * num_grades, a int representing number of grades.  
 */
typedef struct _student 
{ 
  char first_name[50];
  char last_name[50];
  char id[11];
  double *grades; 
  int num_grades; 
} Student;

//Function Declorations
/**
 * @brief add_grade function:
 * Adds a grade to a student
 * 
 * @param student 
 * @param grade 
 */
void add_grade(Student *student, double grade);
/**
 * @brief average function:
 * Returns the grade average of a student
 * 
 * @param student 
 * @return double 
 */
double average(Student *student);
/**
 * @brief print_student function:
 * Prints the Student's members
 * 
 * @param student 
 */
void print_student(Student *student);
/**
 * @brief generate_random_student function:
 * Returns a randomly generate student in the heap with a given number of grades.
 * 
 * @param grades 
 * @return Student* 
 */
Student* generate_random_student(int grades); 
