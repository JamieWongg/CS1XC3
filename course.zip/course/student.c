/**
 * @file student.c
 * @author Jamie Wong (you@domain.com)
 * @brief Library for Student related functions.
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"
/**
 * @brief add_grade function:
 * Adds a grade to a student
 * 
 * @param student 
 * @param grade 
 */
void add_grade(Student* student, double grade)
{
  student->num_grades++;
  
  //If student has only 1 grade
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double)); // Allocate space for one double in the heap initialized to 0 (dynamic array decloration)
  //More than 1 grade
  else 
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades); // Realloc grades to new size of num_grades in the heap
  }
  student->grades[student->num_grades - 1] = grade; 
}
/**
 * @brief average function:
 * Returns the grade average of a student
 * 
 * @param student 
 * @return double 
 */
double average(Student* student)
{
  if (student->num_grades == 0) return 0; //If student has no grades, return 0

  double total = 0;
  //Iterates through grades array and adds grades to running total
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
  return total / ((double) student->num_grades); // calculates average and returns
}

/**
 * @brief print_student function:
 * Prints the Student's members
 * 
 * @param student 
 */
void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  for (int i = 0; i < student->num_grades; i++) // Iterates through grades array and prints grade
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}

/**
 * @brief generate_random_student function:
 * Returns a randomly generate student in the heap with a given number of grades.
 * 
 * @param grades 
 * @return Student* 
 */
Student* generate_random_student(int grades)
{
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
 
  Student *new_student = calloc(1, sizeof(Student)); //Allocates space for 1 Student in the heap (dynamic array decloration)

  //Randomly gives a first and last name from a pool of names
  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);

  //Randomly generates a new student id with 9 digits
  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';

  //Gives random a random grade for each grades
  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  return new_student;
}