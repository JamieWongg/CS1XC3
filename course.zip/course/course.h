/**
 * @file course.h
 * @author Jamie Wong (you@domain.com)
 * @brief Contains structs, and function definitions for course.c
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "student.h"
#include <stdbool.h>
 
/**
 * @brief Course Struct
 * name, a string containing the course name (100 characters length).  
 * code, a string containing the course code (10 characters length).  
 * *student, a Student type containing a dynamic array.  
 * total_students, the int containing the number of students enrolled in the course.  
 * 
 */
typedef struct _course 
{
  char name[100];
  char code[10];
  Student *students;
  int total_students;
} Course;

//Function declarations
/**
 * @brief enroll_student function:
 * Adds a student to a course 
 * 
 * @param course 
 * @param student 
 */
void enroll_student(Course *course, Student *student);
/**
 * @brief print_course function:
 * Prints a Course's members
 * 
 * @param course 
 */
void print_course(Course *course);
/**
 * @brief top_student function:
 * Finds the top student in a course by highest average and returns that student.
 * 
 * @param course 
 * @return Student* 
 */
Student *top_student(Course* course);
/**
 * @brief passing function:
 * Finds and returns a dynamic array containing all students passing a given course. Array size returned in *total_passing.
 * 
 * @param course 
 * @param total_passing 
 * @return Student* 
 */
Student *passing(Course* course, int *total_passing);


